// WARDROBE CATALOG: the list of ready clothes, how to ask for them (in plain words) and the short text that tells the AI they exist.
//
//   plan('red hoodie, blue jeans, white sneakers, beanie, backpack')   -> { items:[{id,slot,col,pat}], missing:[], key }
//   plan('doctor')  /  plan({ outfit:'chef', top:{ color:'red' } })     -> a whole costume
//   native(look, plan, style)       -> the look with the built-in style's own clothing fields set (arm sleeves, trouser type, shoe colour)
//   layers(plan, style, ctx)        -> { back, mid, head, front, defs }  the drawings
//   find('lab coat')                -> { id:'labcoat', ... } | null
//   catalogPrompt() / catalogShort() -> the text for the AI prompt
//
// Pure functions, no DOM.

import { GARMENTS, SLOTS } from './wardrobe-items.js';
import { colorOf, isColorWord, patternOf, PATTERNS, COLOR_LIST, COLORS, PATTERN_ALIASES, renderPlan, normHex, shade } from './wardrobe-core.js';

export { GARMENTS, SLOTS, PATTERNS, COLOR_LIST };

const norm = (s) => String(s == null ? '' : s).replace(/([a-z])([A-Z])/g, '$1 $2').toLowerCase().replace(/[^a-z0-9#]+/g, ' ').trim();
export const ITEM_IDS = Object.freeze([...GARMENTS.keys()]);

// ---------------------------------------------------------------- the whole costumes: [id, other names, items]
// An item is "id", "id:colour" or "id:colour:pattern". (A word before the colon that is not an item id is ignored.)
const OUTFIT_DEFS = [
  // ---- health and science
  ['doctor', 'physician|surgeon|gp|medic|consultant', ['labcoat', 'shirt:#7cc4ee', 'pants:#363a42', 'stethoscope', 'loafers:#1c1c20']],
  ['nurse', 'nursing|male nurse|ward nurse|carer', ['scrubs:#1b8a8a', 'pants:#1b8a8a', 'sneakers:#f5f5f2', 'lanyard:#2f6fd6', 'nursecap:#f5f5f2']],
  ['surgeon', 'operating room|surgery|theatre nurse', ['scrubs:#2f9e4f', 'pants:#2f9e4f', 'surgicalmask:#9fd8f0', 'sneakers:#f5f5f2', 'bandana:#2f9e4f']],
  ['paramedic', 'ambulance|emt|first responder', ['shirt:#2f9e4f', 'cargo:#1c1c20', 'boots:#1c1c20', 'hivis:#f57c20']],
  ['scientist', 'researcher|lab worker|chemist|biologist|professor lab', ['labcoat', 'roundglasses', 'pants:#363a42', 'goggles:#f2a516', 'loafers:#1c1c20']],
  ['patient', 'hospital patient|sick person', ['hospitalgown', 'sandals:#c4c8cf']],
  ['hazmatworker', 'hazmat|biohazard|toxic cleanup', ['hazmat', 'gasmask', 'boots:#f7c52b']],
  // ---- law, security, military, emergency
  ['police', 'cop|policeman|policewoman|police officer|officer|sheriff deputy|constable|detective uniform', ['policeshirt', 'pants:#1b2a5a', 'policecap', 'belt:#1c1c20', 'boots:#1c1c20', 'whistle']],
  ['detective', 'investigator|private eye|sherlock|noir detective|spy detective', ['trench', 'shirt:#f5f5f2', 'pants:#363a42', 'fedora', 'tie:#7a1a2a', 'loafers:#2a1a10']],
  ['sheriff', 'cowboy sheriff|marshal|wild west lawman', ['shortshirt:#c19a6b', 'jeans', 'cowboy:#a8703a', 'holster', 'cowboyboots', 'bolotie']],
  ['security', 'security guard|guard|bodyguard|bouncer|doorman', ['policeshirt:#1c1c20', 'pants:#1c1c20', 'policecap:#1c1c20', 'belt:#1c1c20', 'boots:#1c1c20']],
  ['soldier', 'army|military|marine|infantry|trooper|troops|private|commando', ['uniformjacket:#5a6b3a', 'cargo:#5a6b3a:camo', 'armyhelmet', 'boots:#1c1c20', 'dogtags', 'belt:#3a2a1c']],
  ['general', 'officer military|commander|admiral|army general|colonel', ['uniformjacket:#1b2a5a', 'pants:#1b2a5a', 'policecap:#1b2a5a', 'medal', 'loafers:#1c1c20']],
  ['firefighter', 'fireman|fire fighter|fire brigade|firewoman', ['jacket:#f2a516', 'cargo:#363a42', 'firehelmet', 'boots:#1c1c20', 'hivis:#f7e65a']],
  ['pilot', 'airline pilot|captain pilot|aviator pilot|flight captain|co-pilot', ['pilotshirt', 'pants:#1b2a5a', 'policecap:#1b2a5a', 'aviators', 'tie:#1b2a5a', 'loafers:#1c1c20']],
  ['flightattendant', 'air hostess|stewardess|cabin crew|steward|airline crew', ['pilotshirt:#1b2a5a', 'skirt:#1b2a5a', 'scarf:#d32f2f', 'heels:#1c1c20']],
  ['astronaut', 'cosmonaut|space explorer|space traveller|spaceman|space worker', ['spacesuit', 'spacehelmet', 'boots:#c4c8cf']],
  ['sailor', 'seaman|navy|navy sailor|deckhand|ship crew|seafarer', ['shortshirt:#f5f5f2:stripes', 'pants:#f5f5f2', 'policecap:#f5f5f2', 'neckbandana:#1b2a5a', 'sneakers:#f5f5f2']],
  ['captain', 'ship captain|boat captain|skipper', ['uniformjacket:#1b2a5a', 'pants:#f5f5f2', 'policecap:#f5f5f2', 'medal', 'loafers:#1c1c20']],
  ['judge', 'justice|magistrate|court judge', ['judgerobe', 'shirt:#f5f5f2', 'tie:#1c1c20']],
  ['lawyer', 'attorney|barrister|solicitor|advocate|counsel', ['suitjacket:#363a42', 'shirt:#f5f5f2', 'pants:#363a42', 'tie:#7a1a2a', 'briefcase', 'loafers:#1c1c20']],
  ['prisoner', 'inmate|convict|jailbird|prison uniform', ['tshirt:#f2a516:stripes', 'pants:#f2a516', 'sneakers:#f5f5f2']],
  ['robber', 'burglar|thief|bandit|criminal|crook|masked thief', ['longsleeve:#1c1c20:stripes', 'pants:#1c1c20', 'balaclavahat', 'duffelbag:#1c1c20', 'sneakers:#1c1c20']],
  ['spy', 'secret agent|agent|special agent|bond|undercover', ['suitjacket:#1c1c20', 'shirt:#f5f5f2', 'pants:#1c1c20', 'bowtie:#1c1c20', 'sunglasses', 'loafers:#1c1c20']],
  // ---- work, food, trades
  ['chef', 'cook|head chef|kitchen chef|restaurant cook|sous chef|baker chef', ['chefjacket', 'pants:#363a42:checks', 'chefhat', 'apron:#f5f5f2', 'sneakers:#1c1c20']],
  ['baker', 'pastry chef|bakery worker|bread maker', ['tshirt:#f5f5f2', 'apron:#f5f5f2', 'jeans', 'chefhat', 'sneakers:#f5f5f2']],
  ['waiter', 'waitress|server|barista|bartender|restaurant staff', ['shirt:#f5f5f2', 'pants:#1c1c20', 'waistapron', 'bowtie:#1c1c20', 'loafers:#1c1c20']],
  ['butcher', 'meat cutter|deli worker|fishmonger', ['shortshirt:#f5f5f2', 'apron:#d32f2f:stripes', 'pants:#363a42', 'bandana:#f5f5f2', 'boots:#f5f5f2']],
  ['farmer', 'rancher|agriculture|crop farmer|farm worker|gardener farmer|villager', ['flannel:#c8302a', 'overallsbib:#3f5f8f', 'jeans', 'sunhat', 'boots:#6b4423']],
  ['gardener', 'landscaper|groundskeeper|florist worker', ['shortshirt:#f5f5f2', 'overallsbib:#5a6b3a', 'shorts:#c19a6b', 'sunhat', 'rainboots:#2f9e4f']],
  ['construction', 'builder|construction worker|site worker|labourer|laborer|engineer site|bricklayer|miner', ['tshirt:#f5f5f2', 'hivis', 'cargo:#c19a6b', 'hardhat', 'toolbelt', 'boots:#6b4423']],
  ['mechanic', 'car mechanic|garage worker|technician|plumber|electrician|handyman|repairman', ['jumpsuit:#1b2a5a', 'cap:#d32f2f', 'toolbelt', 'boots:#4a2c1a']],
  ['welder', 'metalworker|blacksmith|factory worker', ['jacket:#4a2c1a', 'jeans', 'goggles:#f2a516', 'boots:#4a2c1a', 'waistapron:#6b4423']],
  ['delivery', 'courier|postman|mailman|delivery driver|dispatch rider|uber rider', ['polo:#d32f2f', 'shorts:#363a42', 'cap:#d32f2f', 'messenger', 'sneakers:#f5f5f2']],
  ['driver', 'taxi driver|bus driver|truck driver|chauffeur|cab driver|trucker', ['shortshirt:#7cc4ee', 'pants:#363a42', 'cap:#363a42', 'loafers:#1c1c20']],
  ['office', 'office worker|businessman|businesswoman|corporate|professional|manager|ceo|boss|executive|banker|accountant|salesman', ['suitjacket:#363a42', 'shirt:#f5f5f2', 'pants:#363a42', 'tie:#1b2a5a', 'briefcase', 'loafers:#1c1c20']],
  ['officewoman', 'office lady|corporate woman|businesswoman suit|female executive|secretary|receptionist', ['blazer:#363a42', 'blouse:#f5f5f2', 'pencilskirt:#363a42', 'heels:#1c1c20', 'handbag:#1c1c20', 'pearlnecklace']],
  ['casualoffice', 'startup|tech worker|developer|programmer|coder|designer casual|freelancer', ['hoodie:#5a6b3a', 'jeans', 'sneakers:#f5f5f2', 'roundglasses', 'backpack:#363a42', 'neckphones']],
  ['hacker', 'cyber hacker|black hat|netrunner|coder hoodie', ['hoodie:#1c1c20', 'jeans:#1c1c20', 'hoodup:#1c1c20', 'sneakers:#1c1c20', 'sunglasses']],
  ['teacher', 'professor|lecturer|tutor|instructor|headmaster|principal', ['cardigan:#9bb59a', 'shirt:#f5f5f2', 'pants:#363a42', 'roundglasses', 'lanyard:#2f6fd6', 'loafers:#2a1a10']],
  ['student', 'schoolboy|schoolgirl|pupil|school kid|school child|schoolchild|kid at school', ['schoolblazer:#1b2a5a', 'shirt:#f5f5f2', 'pants:#363a42', 'tie:#1b2a5a', 'schoolbag', 'loafers:#1c1c20']],
  ['schoolgirl', 'girl student|female student school', ['schoolblazer:#1b2a5a', 'blouse:#f5f5f2', 'pleated:#1b2a5a', 'tie:#d32f2f', 'schoolbag', 'flats:#1c1c20']],
  ['collegestudent', 'university student|uni student|campus student|undergrad', ['hoodie:#7b3fa8', 'jeans', 'sneakers:#f5f5f2', 'backpack:#363a42', 'headphones']],
  ['graduate', 'graduation|graduating student|grad|alumni', ['judgerobe:#1b2a5a', 'gradcap', 'shirt:#f5f5f2', 'loafers:#1c1c20', 'medal']],
  ['librarian', 'bookworm|archivist|clerk', ['cardigan:#8a94e8', 'blouse:#f5f5f2', 'midiskirt:#363a42', 'halfglasses', 'flats:#4a2c1a']],
  ['artist', 'painter|sculptor|illustrator|creative|bohemian artist', ['shirt:#f5f5f2:stripes', 'apron:#9bb59a', 'jeans:#363a42', 'beret:#d32f2f', 'sneakers:#f5f5f2']],
  ['photographer', 'cameraman|reporter|journalist|press|news reporter|paparazzi', ['jacket:#5a6b3a', 'tshirt:#1c1c20', 'cargo:#7a8a2a', 'neckcamera', 'lanyard:#d32f2f', 'sneakers:#1c1c20']],
  ['anchor', 'newsreader|news anchor|tv host|presenter|host', ['blazer:#1b2a5a', 'blouse:#f5f5f2', 'pants:#1b2a5a', 'heels:#1c1c20']],
  ['musician', 'guitarist|rockstar|rock star|band member|singer|vocalist|drummer', ['leather:#1c1c20', 'graphictee:#1c1c20', 'skinnyjeans:#1c1c20', 'boots:#1c1c20', 'sunglasses']],
  ['rapper', 'hip hop|hip-hop|trap artist|mc|street style|streetwear|urban', ['hoodie:#f5f5f2', 'joggers:#1c1c20', 'hightops:#d32f2f', 'chain', 'sunglasses', 'cap:#1c1c20']],
  ['dj', 'club dj|disc jockey|party dj', ['tshirt:#1c1c20', 'jeans:#1c1c20', 'headphones:#d32f2f', 'neckphones', 'sneakers:#39ff88', 'sunglasses']],
  ['popstar', 'celebrity|pop singer|diva|performer|idol|stage outfit|k-pop', ['minidress:#d63aa0:sequin', 'heels:#d4af37', 'dropearrings', 'tiara']],
  ['punk', 'punk rock|punk rocker|emo|goth punk', ['leather:#1c1c20', 'graphictee:#1c1c20', 'skinnyjeans:#1c1c20:plaid', 'boots:#1c1c20', 'choker', 'belt:#1c1c20']],
  ['goth', 'gothic|dark fashion|emo girl|vampire fashion', ['minidress:#1c1c20:lace', 'boots:#1c1c20', 'choker', 'lipstick:#6d1f35', 'cape:#1c1c20']],
  ['hippie', 'boho|flower child|60s hippie|peace|festival|bohemian', ['peasant:#f3ecd8', 'palazzo:#2fc4c0:floral', 'headband:#d9a21b', 'beadsnecklace', 'roundglasses', 'sandals']],
  ['disco', '70s|seventies|retro|funky|saturday night', ['shirt:#7b3fa8', 'slacksflare:#f5f5f2', 'chain', 'sunglasses', 'heels:#f5f5f2']],
  ['eighties', '80s|eighties|retro 80s|neon 80s|synthwave', ['trackjacket:#ff3fa8', 'leggings:#39ff88', 'headband:#f5ff3a', 'sunglasses:#ff3fa8', 'hightops:#f5f5f2']],
  // ---- sport
  ['footballer', 'soccer player|football player|striker|goalkeeper|footy|soccer kit|football kit', ['jersey:#d32f2f', 'gymshorts:#f5f5f2', 'cleats:#39ff88', 'headband:#f5f5f2']],
  ['basketball', 'basketballer|nba|hooper|basketball player', ['basketballjersey:#f2a516', 'gymshorts:#f2a516', 'hightops:#f5f5f2', 'headband:#d32f2f']],
  ['runner', 'jogger|marathon|track athlete|sprinter|athlete|running', ['tank:#39ff88', 'gymshorts:#1c1c20', 'sneakers:#f5f5f2', 'headband:#f5f5f2', 'visor']],
  ['gym', 'gym bro|gym rat|fitness|workout|trainer|personal trainer|bodybuilder|crossfit', ['tank:#1c1c20', 'gymshorts:#363a42', 'sneakers:#f5f5f2', 'headband:#d32f2f', 'neckphones']],
  ['yoga', 'yogi|pilates|stretching|meditation outfit', ['camisole:#b9a4e6', 'leggings:#1c1c20', 'barefoot']],
  ['boxer', 'fighter|mma fighter|wrestler|kickboxer', ['basketballjersey:#d32f2f', 'gymshorts:#d32f2f:stripes', 'boots:#f5f5f2', 'belt:#d4af37']],
  ['karate', 'martial artist|judo|taekwondo|sensei|kung fu|dojo', ['karategi', 'belt:#1c1c20', 'bandana:#f5f5f2', 'barefoot']],
  ['swimmer', 'swimming|beach|pool|bather|lifeguard swim|beachgoer|summer beach', ['swimtrunks:#27b8e0', 'goggles:#2f6fd6', 'sandals:#f5f5f2', 'sunhat']],
  ['swimmergirl', 'bikini girl|beach girl|girl at the beach|sunbather', ['bikini:#ff7f6e', 'sunhat', 'heartshades', 'sandals:#f5f5f2', 'totebag']],
  ['lifeguard', 'beach lifeguard|pool guard', ['tank:#d32f2f', 'swimtrunks:#d32f2f', 'visor:#d32f2f', 'whistle', 'sunglasses', 'sandals:#f5f5f2']],
  ['diver', 'scuba diver|scuba|snorkeller|frogman|underwater', ['wetsuit', 'goggles:#27b8e0', 'scubatank', 'flippers']],
  ['surfer', 'surf|surfing|beach boy|wave rider', ['swimtrunks:#2fc4c0:tropical', 'tank:#f5f5f2', 'lei', 'sunglasses', 'barefoot']],
  ['skater', 'skateboarder|skate kid|bmx rider', ['graphictee:#1c1c20', 'widejeans:#5a6577', 'hightops:#f5f5f2', 'beanie:#d32f2f', 'bikehelmet']],
  ['cyclist', 'cycling|biker bicycle|bike rider|bicycle rider|tour de france', ['tshirt:#f7e65a', 'bikeshorts:#1c1c20', 'bikehelmet', 'sunglasses', 'sneakers:#f5f5f2']],
  ['biker', 'motorcyclist|motorbike rider|motorcycle rider|rider|hells', ['leather:#1c1c20', 'jeans:#1c1c20', 'bikehelmet:#1c1c20', 'boots:#1c1c20', 'sunglasses']],
  ['skier', 'snowboarder|snow sports|winter sports|alpine', ['puffer:#2f6fd6', 'joggers:#1c1c20', 'goggles:#f2a516', 'beanie:#d32f2f', 'skiboots']],
  ['ballerina', 'dancer|ballet dancer|ballet|dance class', ['ballet:#f3b8c4', 'tutu:#f3b8c4', 'ballethoes', 'hairbow']],
  ['gymnast', 'cheerleader|acrobat|circus acrobat', ['ballet:#d32f2f', 'pleated:#d32f2f', 'hairbow:#d32f2f', 'sneakers:#f5f5f2']],
  ['golfer', 'golf|country club|tennis player|tennis', ['polo:#f5f5f2', 'chinos:#9bb59a', 'visor:#f5f5f2', 'sneakers:#f5f5f2']],
  ['baseball', 'baseball player|pitcher|batter|softball', ['jersey:#1b2a5a', 'pants:#f5f5f2', 'cap:#1b2a5a', 'sneakers:#1c1c20']],
  ['footballusa', 'american football|quarterback|nfl|linebacker', ['jersey:#1b2a5a', 'gymshorts:#f5f5f2', 'footballhelmet', 'cleats:#f5f5f2']],
  ['referee', 'umpire|ref|match official', ['shortshirt:#1c1c20:stripes', 'gymshorts:#1c1c20', 'whistle', 'sneakers:#1c1c20', 'visor:#1c1c20']],
  ['rugbyplayer', 'rugby|scrum|hockey player|ice hockey', ['rugby:#1f4fb0', 'gymshorts:#f5f5f2', 'cleats:#1c1c20', 'headband:#f5f5f2']],
  // ---- history, fantasy, myth, costume
  ['king', 'monarch|emperor|sultan|pharaoh|tsar|ruler|lord|royal man|prince', ['overcoat:#7a1a2a', 'shirt:#f5f5f2', 'pants:#363a42', 'crown', 'cape:#7a1a2a', 'chain', 'boots:#4a2c1a']],
  ['queen', 'empress|princess|royal woman|lady royal|duchess|noblewoman', ['gown:#7b3fa8', 'crown', 'cape:#7a1a2a', 'dropearrings', 'pearlnecklace', 'heels:#d4af37']],
  ['knight', 'crusader|paladin|medieval warrior|templar|armored|armoured|squire', ['uniformjacket:#8a8f98', 'pants:#8a8f98', 'knighthelmet', 'cape:#d32f2f', 'boots:#4a2c1a', 'belt:#3a2a1c', 'swordonback']],
  ['viking', 'norseman|norse|barbarian|warrior|berserker|conan', ['tunic:#6b4423', 'pants:#4a2c1a', 'vikinghelmet', 'fakebeard', 'boots:#4a2c1a', 'belt:#3a2a1c']],
  ['samurai', 'ronin|shogun|feudal japan|bushi', ['kimono:#1b2a5a', 'hakama:#1c1c20', 'obi:#d32f2f', 'swordonback', 'sandals:#4a2c1a']],
  ['ninja', 'shinobi|assassin|stealth|kunoichi|ninja warrior', ['ninjasuit', 'ninjamask', 'bandana:#d32f2f', 'boots:#1c1c20', 'swordonback']],
  ['wizard', 'sorcerer|mage|warlock|magician fantasy|merlin|gandalf|dumbledore|spellcaster', ['wizardrobe:#3b3a9a', 'wizardhat:#3b3a9a', 'fakebeard:#f5f5f2', 'sash:#d4af37', 'boots:#4a2c1a']],
  ['witch', 'sorceress|enchantress|halloween witch|hex', ['wizardrobe:#1c1c20', 'witchhat', 'boots:#1c1c20', 'cape:#7b3fa8']],
  ['magician', 'illusionist|stage magician|conjuror|houdini|ringmaster', ['suitjacket:#1c1c20', 'shirt:#f5f5f2', 'pants:#1c1c20', 'tophat', 'cape:#7a1a2a', 'bowtie:#d32f2f', 'loafers:#1c1c20']],
  ['pirate', 'buccaneer|corsair|sea rover|privateer|captain hook|jack sparrow', ['shirt:#f3ecd8', 'vest:#7a1a2a', 'pants:#363a42', 'bandana:#d32f2f', 'eyepatch', 'boots:#4a2c1a', 'belt:#3a2a1c', 'hoopearrings']],
  ['cowboy', 'cowgirl|western|wild west|rodeo|gunslinger|outlaw|cattle driver|ranch hand', ['flannel:#c8302a:plaid', 'jeans', 'cowboy', 'cowboyboots', 'belt:#4a2c1a', 'neckbandana:#c8302a']],
  ['caveman', 'caveperson|stone age|neanderthal|primitive|prehistoric', ['tunic:#a8703a:leopard', 'barefoot', 'beadsnecklace']],
  ['gladiator', 'roman soldier|centurion|spartan|roman|ancient greek|greek warrior', ['toga:#d32f2f', 'knighthelmet', 'belt:#d4af37', 'sandals:#a8703a', 'cape:#d32f2f']],
  ['greek', 'greek god|zeus|goddess|ancient greece|olympian|roman senator', ['toga:#f5f5f2', 'laurel', 'sash:#d4af37', 'sandals:#d4af37']],
  ['egyptian', 'pharaoh egypt|cleopatra|ancient egypt|mummy queen|egypt', ['toga:#f5f5f2', 'crown:#d4af37', 'chain:#d4af37', 'sandals:#d4af37']],
  ['robinhood', 'archer|huntsman|forest hunter|elf ranger|ranger green', ['tunic:#2f5f3a', 'pants:#6b4423', 'feathercap', 'quiver', 'boots:#4a2c1a', 'belt:#3a2a1c']],
  ['musketeer', 'cavalier|swashbuckler|duelist|renaissance noble|nobleman|baroque', ['blazer:#1b2a5a', 'shirt:#f5f5f2', 'pants:#363a42', 'feathercap', 'cape:#1b2a5a', 'boots:#4a2c1a', 'ruff']],
  ['victorian', 'victorian man|gentleman|1800s|old london|dickens|oliver twist', ['suitjacket:#4a4f5a', 'vest:#7a1a2a', 'shirt:#f5f5f2', 'pants:#363a42', 'bowler', 'bowtie:#1c1c20', 'loafers:#1c1c20']],
  ['victoriangirl', 'victorian lady|1800s lady|regency|bridgerton|old fashioned dress|period dress', ['gown:#9bb59a', 'sunhat:#f5f5f2', 'pearlnecklace', 'heels:#f5f5f2']],
  ['maid', 'housemaid|servant|housekeeper|french maid|cleaner', ['pinafore:#1c1c20', 'blouse:#f5f5f2', 'hairbow:#f5f5f2', 'flats:#1c1c20']],
  ['monk', 'friar|priest|pastor|clergy|abbot|nun|buddhist monk|monastery|preacher', ['monkrobe', 'sandals:#4a2c1a', 'crossnecklace']],
  ['arabian', 'arab|arabian|sheikh|desert nomad|bedouin|middle eastern', ['kaftan:#f5f5f2', 'turban:#f5f5f2', 'sandals:#a8703a']],
  ['nigerian', 'naija|yoruba|igbo|hausa|nigerian traditional|african traditional|nigerian wedding|owambe|aso ebi', ['kaftan:#c8302a:ankara', 'gele:#d9a21b', 'sandals:#d4af37', 'beadsnecklace']],
  ['nigerianman', 'agbada|yoruba man|igbo chief|nigerian chief|native attire|senator wear|buba and sokoto', ['kaftan:#f5f5f2', 'fez:#c8302a', 'sandals:#4a2c1a', 'beadsnecklace:#c8302a']],
  ['indian', 'desi|bollywood|indian traditional|diwali|saree girl|punjabi|hindu', ['sari:#d63aa0', 'bindi', 'dropearrings', 'sandals:#d4af37']],
  ['indianman', 'kurta man|sherwani|indian man traditional|punjabi man', ['tunic:#f7c52b', 'palazzo:#f5f5f2', 'turban:#d32f2f', 'sandals:#a8703a']],
  ['chinese', 'china traditional|chinese new year|hanfu|qipao girl|lunar new year', ['qipao:#d32f2f', 'hairbow:#d4af37', 'flats:#d32f2f']],
  ['kimonogirl', 'geisha|japanese traditional|yukata girl|japan festival', ['kimono:#c2307e', 'obi:#d4af37', 'flowercrown', 'sandals:#a8703a']],
  ['mexican', 'mariachi|el charro|latino traditional|dia de muertos|mexico', ['shirt:#f5f5f2', 'pants:#1c1c20', 'sombrero', 'bolotie', 'cowboyboots:#1c1c20']],
  ['scottish', 'highlander|bagpiper|scot|braveheart', ['shirt:#f5f5f2', 'kilt:#7a1a2a', 'sporran', 'boots:#4a2c1a', 'flatcap']],
  ['hawaiian', 'aloha|tropical tourist|luau|island|tourist|holiday maker|vacation', ['hawaiian', 'shorts:#f5f5f2', 'lei', 'sunglasses', 'sunhat', 'sandals']],
  ['hiker', 'camper|backpacker|trekker|outdoorsman|explorer|adventurer|safari|ranger park|scout', ['flannel:#c8302a', 'cargo:#5a6b3a', 'hikingpack', 'bucket:#7a8a2a', 'boots:#4a2c1a']],
  ['explorer', 'archaeologist|indiana jones|treasure hunter|tomb raider|jungle explorer', ['shortshirt:#c19a6b', 'cargo:#c19a6b', 'fedora', 'hikingpack', 'boots:#4a2c1a', 'belt:#4a2c1a']],
  ['santa', 'father christmas|saint nick|christmas man|st nick|claus', ['jacket:#d32f2f', 'pants:#d32f2f', 'santahat', 'fakebeard:#f5f5f2', 'belt:#1c1c20', 'boots:#1c1c20']],
  ['elf', 'christmas elf|santa helper|helper elf|woodland elf', ['tunic:#2f9e4f', 'leggings:#d32f2f:stripes', 'pombeanie:#d32f2f', 'boots:#d32f2f', 'belt:#d4af37']],
  ['angel', 'cherub|seraph|heavenly|saint|heaven', ['kaftan:#f5f5f2', 'angelwings', 'halo', 'barefoot']],
  ['devil', 'demon|satan|imp|hell|lucifer|evil spirit', ['jumpsuit:#d32f2f', 'devilhorns', 'devilTail', 'cape:#7a1a2a', 'boots:#1c1c20']],
  ['vampire', 'dracula|count dracula|bloodsucker|nosferatu|undead noble', ['suitjacket:#1c1c20', 'shirt:#f5f5f2', 'pants:#1c1c20', 'cape:#7a1a2a', 'bowtie:#7a1a2a', 'loafers:#1c1c20']],
  ['zombie', 'undead|walking dead|ghoul|living dead|corpse', ['shirt:#6b4423', 'pants:#4a4f5a', 'barefoot']],
  ['ghost', 'spirit|phantom|spook|haunt|poltergeist', ['kaftan:#f5f5f2', 'barefoot']],
  ['mummy', 'egyptian mummy|bandaged|wrapped', ['bodysuit:#f3ecd8:stripes', 'barefoot']],
  ['clown', 'jester|circus clown|joker|harlequin|funny man|buffoon', ['jumpsuit:#d32f2f:polka', 'clownnose', 'ruff:#f5f5f2', 'beanie:#2f6fd6', 'flippers:#f7c52b']],
  ['superhero', 'hero|caped hero|crime fighter|super hero|avenger|vigilante|masked hero', ['superhero', 'cape:#d32f2f', 'banditmask:#d32f2f', 'belt:#d4af37', 'boots:#d32f2f']],
  ['supervillain', 'villain|evil genius|mastermind|dark lord|bad guy|henchman|evil overlord', ['suitjacket:#1c1c20', 'cape:#7a1a2a', 'pants:#1c1c20', 'handlebar', 'boots:#1c1c20', 'sunglasses']],
  ['alien', 'martian|extraterrestrial|ufo|space creature|et', ['jumpsuit:#39ff88', 'antennae:#39ff88', 'boots:#7b3fa8']],
  ['robot', 'android|cyborg|mech|bot|automaton|tin man', ['jumpsuit:#c4c8cf', 'vrheadset:#c4c8cf', 'antennae:#c4c8cf', 'boots:#8a8f98']],
  ['scifi', 'futuristic|cyberpunk|space marine|sci-fi|spaceship crew|starship officer|star trek|rebel', ['jumpsuit:#2f6fd6', 'sash:#c4c8cf', 'belt:#c4c8cf', 'boots:#1c1c20']],
  ['cyberpunk', 'neon street|dystopian|neon punk|future punk|blade runner', ['leather:#1c1c20', 'leggings:#1c1c20', 'sunglasses:#39ff88', 'boots:#1c1c20', 'choker:#39ff88']],
  ['steampunk', 'victorian sci-fi|brass inventor|clockwork|gear punk|airship captain', ['vest:#6b4423', 'shirt:#f5f5f2', 'pants:#4a2c1a', 'tophat:#4a2c1a', 'goggles:#d4af37', 'boots:#4a2c1a']],
  ['fairy', 'pixie|sprite|fae|forest fairy|tinkerbell|nymph', ['minidress:#9bb59a', 'fairywings', 'flowercrown', 'barefoot']],
  ['mermaid', 'siren|sea nymph|sea princess|merfolk', ['bikini:#2fc4c0:snakeskin', 'pearlnecklace', 'flowercrown:#2fc4c0']],
  ['catgirl', 'neko|cat cosplay|kitty|cat costume|anime cat', ['minidress:#1c1c20', 'catears', 'foxtail:#1c1c20', 'whiskers', 'choker:#d32f2f']],
  ['bunny', 'rabbit costume|easter bunny|bunny costume|playboy bunny', ['onesie:#f5f5f2', 'bunnyears', 'foxtail:#f5f5f2']],
  ['bear', 'teddy bear|bear costume|panda costume|animal costume|mascot', ['onesie:#7a4a2a', 'bearears', 'foxtail:#7a4a2a']],
  ['princessdress', 'fairytale princess|disney princess|cinderella|snow white|storybook princess|royal girl', ['gown:#f08fb0', 'tiara', 'pearlnecklace', 'heels:#c4c8cf']],
  ['bride', 'wedding bride|bridal|just married bride|marry|brides', ['wedding', 'tiara:#f5f5f2', 'pearlnecklace', 'studs', 'heels:#f5f5f2']],
  ['groom', 'wedding groom|just married groom|best man|bridegroom', ['suitjacket:#1c1c20', 'shirt:#f5f5f2', 'pants:#1c1c20', 'bowtie:#1c1c20', 'loafers:#1c1c20']],
  ['partygirl', 'party|night out|clubbing|cocktail|date night|prom|prom night|evening', ['minidress:#d63aa0', 'heels:#1c1c20', 'dropearrings', 'lipstick:#c2307e', 'handbag:#1c1c20']],
  ['partyguy', 'formal man|black tie|gala|wedding guest man|prom guy|date night guy|smart man|dapper', ['suitjacket:#1b2a5a', 'shirt:#f5f5f2', 'pants:#1b2a5a', 'bowtie:#1c1c20', 'loafers:#1c1c20']],
  ['birthday', 'birthday party|party kid|birthday boy|birthday girl|celebration', ['tshirt:#f2a516', 'jeans', 'partyhat', 'sneakers:#f5f5f2']],
  // ---- everyday
  ['casual', 'everyday|normal|regular|average|relaxed|jeans and tee|plain|ordinary|default outfit', ['tshirt', 'jeans', 'sneakers']],
  ['casualgirl', 'casual woman|everyday girl|girl next door|normal girl', ['tshirt:#f08fb0', 'denimskirt', 'sneakers:#f5f5f2', 'backpack:#c2307e']],
  ['smartcasual', 'smart casual|business casual|date outfit|brunch|dinner date', ['shirt:#7cc4ee', 'chinos:#c19a6b', 'loafers:#4a2c1a', 'belt:#4a2c1a']],
  ['winter', 'cold weather|snow day|christmas outfit|freezing|winter coat outfit|bundled up|winter clothes', ['puffer:#d32f2f', 'jeans', 'scarf:#f5f5f2', 'beanie:#1b2a5a', 'boots:#4a2c1a']],
  ['rainy', 'rain outfit|wet weather|umbrella weather|rainy day', ['raincoat:#f7c52b', 'jeans', 'rainboots:#f7c52b', 'hoodup:#f7c52b']],
  ['summer', 'hot weather|sunny day|summer outfit|holiday|beach day|warm weather|summer clothes', ['tank:#f5f5f2', 'shorts:#27b8e0', 'sunglasses', 'sandals', 'cap:#f2a516']],
  ['autumn', 'fall|fall outfit|autumn outfit|cosy|cozy|sweater weather|thanksgiving', ['sweater:#b5502a', 'jeans', 'scarf:#d9a21b', 'boots:#6b4423', 'beanie:#6b4423']],
  ['spring', 'spring outfit|easter|garden party|picnic', ['cardigan:#f3b8c4', 'sundress:#f7e65a', 'flats:#f5f5f2', 'sunhat']],
  ['sleepwear', 'bedtime|going to bed|night clothes|just woke up|morning at home|lazy day|pyjama|pj|sleepy', ['pajamas', 'joggers:#7cc4ee', 'sandals:#8a94e8']],
  ['homewear', 'at home|lounge|lounging|relaxing at home|house clothes|chilling', ['sweatshirt:#8a8f98', 'joggers:#5a6577', 'sandals:#363a42']],
  ['hoodiekid', 'teen|teenager|young kid|kid casual|boy casual|skater boy|hoodie and jeans', ['hoodie:#2f6fd6', 'jeans', 'hightops:#f5f5f2', 'backpack:#d32f2f']],
  ['grandma', 'granny|elderly woman|old woman|nana|grandmother|old lady', ['cardigan:#b08aa8', 'blouse:#f5f5f2', 'midiskirt:#7a1a2a', 'halfglasses', 'pearlnecklace', 'flats:#4a2c1a']],
  ['grandpa', 'grandfather|old man|elderly man|grandad|pensioner|retired man|old gentleman', ['vsweater:#6b4423', 'shirt:#f5f5f2', 'pants:#4a4f5a', 'flatcap:#6b4423', 'halfglasses', 'loafers:#4a2c1a']],
  ['baby', 'toddler|infant|newborn|little baby|small child', ['onesie:#7cc4ee', 'beanie:#f5f5f2']],
  ['tourist', 'traveller|traveler|backpacker tourist|sightseer|visitor', ['hawaiian', 'cargo:#c19a6b', 'sunhat', 'neckcamera', 'backpack:#2f6fd6', 'sandals']],
  ['shopper', 'shopping|customer|mall|buyer|window shopper|shopaholic', ['tshirt', 'jeans', 'sneakers', 'totebag', 'sunglasses']],
  ['beggar', 'homeless|poor man|street person|tramp|hobo|vagrant|poor|ragged|refugee', ['sweater:#6b4423', 'pants:#4a4f5a', 'beanie:#4a4f5a', 'scarf:#8a8f98', 'sandals:#4a2c1a']],
  ['rich', 'wealthy|billionaire|tycoon|rich man|millionaire|luxury|fancy|expensive|elite', ['suitjacket:#1c1c20', 'shirt:#f5f5f2', 'pants:#1c1c20', 'chain:#d4af37', 'sunglasses', 'loafers:#1c1c20']],
  ['richwoman', 'rich lady|wealthy woman|socialite|luxury woman|first lady|lady of leisure', ['blazer:#f5f5f2', 'minidress:#c2307e', 'sunglasses', 'handbag:#d4af37', 'heels:#1c1c20', 'pearlnecklace']],
  ['gamer', 'esports|streamer|twitch|gaming|pro gamer|nerd|geek|otaku', ['hoodie:#7b3fa8', 'jeans:#363a42', 'headphones', 'sneakers:#f5f5f2', 'roundglasses']],
  ['nerd', 'geek student|bookish|brainy|swot|dork|science nerd', ['shortshirt:#f5f5f2', 'pants:#4a4f5a', 'squareglasses', 'vest:#9bb59a', 'bowtie:#d32f2f', 'loafers:#1c1c20']],
  ['influencer', 'vlogger|content creator|youtuber|tiktoker|blogger|social media star', ['croptee:#f08fb0', 'jeans', 'sneakers:#f5f5f2', 'sunglasses', 'crossbody']],
  ['model', 'fashion model|runway|catwalk|supermodel|fashion|stylish', ['minidress:#1c1c20', 'heels:#c2307e', 'sunglasses', 'dropearrings', 'handbag:#d4af37']],
  ['mourner', 'funeral|black outfit|widow|mourning|grief', ['suitjacket:#1c1c20', 'shirt:#f5f5f2', 'pants:#1c1c20', 'tie:#1c1c20', 'sunglasses', 'loafers:#1c1c20']],
  ['pyjamaparty', 'sleepover|slumber party|kids pajama|pajama party', ['pajamas:#f08fb0:stars', 'sandals:#f3b8c4', 'bearears']],
];

const OUTFITS = new Map();
for (const [id, aka, items] of OUTFIT_DEFS) OUTFITS.set(id, { id, aka: aka.split('|'), items });
export const OUTFIT_IDS = Object.freeze([...OUTFITS.keys()]);

// ---------------------------------------------------------------- word index
const IDX = []; // { phrase, id, kind:'item'|'outfit', len }
const addIdx = (ph, id, kind, w) => { const n = norm(ph); if (n) IDX.push({ phrase: n, id, kind, len: n.split(' ').length, w }); };
for (const g of GARMENTS.values()) { addIdx(g.id, g.id, 'item', 3); for (const a of g.aka) addIdx(a, g.id, 'item', 3); }
for (const o of OUTFITS.values()) { addIdx(o.id, o.id, 'outfit', 1); for (const a of o.aka) addIdx(a, o.id, 'outfit', 1); }
IDX.sort((a, b) => b.len - a.len || b.phrase.length - a.phrase.length || b.w - a.w);
const IDX_MAP = new Map(); for (const e of IDX) if (!IDX_MAP.has(e.phrase)) IDX_MAP.set(e.phrase, e);
const STOP = new Set(['a', 'an', 'the', 'of', 'in', 'on', 'wearing', 'wears', 'wear', 'dressed', 'as', 'with', 'and', 'his', 'her', 'their', 'its', 'some', 'pair', 'plus', 'also', 'outfit', 'clothes', 'clothing', 'costume', 'uniform', 'look', 'style', 'person', 'who', 'is', 'has', 'having', 'put', 'on', 'over', 'under', 'to', 'for', 'sporting', 'rocking']);
const singular = (w) => (w.length > 3 && w.endsWith('ies') ? w.slice(0, -3) + 'y' : w.length > 3 && /(ses|xes|ches|shes)$/.test(w) ? w.slice(0, -2) : w.length > 3 && w.endsWith('s') && !w.endsWith('ss') ? w.slice(0, -1) : w);

/** What does this phrase name? -> { kind:'item'|'outfit', id } | null. Longest phrase first, then single words (and their singular). */
export function find(text) {
  const t = norm(text);
  if (!t) return null;
  const hit = IDX_MAP.get(t) || IDX_MAP.get(t.split(' ').map(singular).join(' '));
  if (hit) return { kind: hit.kind, id: hit.id };
  const words = t.split(' ');
  // longest run of words that is a known name
  for (let n = Math.min(4, words.length); n >= 1; n--) for (let i = 0; i + n <= words.length; i++) {
    const ph = words.slice(i, i + n).join(' '), h = IDX_MAP.get(ph) || IDX_MAP.get(words.slice(i, i + n).map(singular).join(' '));
    if (h && !(n === 1 && (STOP.has(ph) || isColorWord(ph) || patternOf(ph)))) return { kind: h.kind, id: h.id };
  }
  return null;
}

// ---------------------------------------------------------------- reading a request into a plan
const CONFLICT = { dress: ['top', 'bottom'], top: ['dress'], bottom: ['dress'] };
const MULTI = new Set(['jewel', 'neck', 'face']);
function addItem(items, it) {
  const g = GARMENTS.get(it.id);
  if (!g) return;
  const slot = g.slot;
  const out = items.filter((x) => {
    if (x.id === it.id) return false;
    if (CONFLICT[slot] && CONFLICT[slot].includes(x.slot)) return false;
    if (!MULTI.has(slot) && x.slot === slot) return false;
    return true;
  });
  out.push({ id: it.id, slot, col: it.col || g.col[0], col2: it.col2 || '', pat: g.pat ? (it.pat || '') : '', num: it.num });
  items.length = 0; items.push(...out);
}
function chunkToItem(chunk, items, missing) {
  let t = String(chunk || '');
  const spec = /^([a-z0-9_]+)(?::(#[0-9a-f]{3,6}|[a-z ]+))?(?::([a-z ]+))?$/i.exec(t.trim());
  if (spec && GARMENTS.has(spec[1])) {
    const col = spec[2] ? colorOf(spec[2]) : '', pat = spec[3] ? patternOf(spec[3]) : '';
    addItem(items, { id: spec[1], col, pat });
    return;
  }
  const raw = norm(t);
  if (!raw) return;
  const words = raw.split(' ').filter((w) => w && !STOP.has(w));
  // colours: all colour words (the first is the main colour, a second after "and" in a chunk is the accent); patterns
  let col = '', col2 = '', pat = '';
  const rest = [];
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    if (IDX_MAP.has(w) && (!isColorWord(w) || IDX_MAP.get(w).kind === 'item')) { rest.push(w); continue; }
    const hx = normHex(w);
    if (hx) { if (!col) col = hx; else if (!col2) col2 = hx; continue; }
    if (isColorWord(w)) {
      // "dark red" / "light blue": modifier + colour
      let phrase = w;
      while (i + 1 < words.length && isColorWord(words[i + 1]) && (['dark', 'deep', 'light', 'pale', 'pastel', 'bright', 'dusty'].includes(phrase.split(' ')[0]) || phrase.split(' ').length === 1 && ['sky', 'navy', 'royal', 'neon', 'rose', 'forest', 'olive', 'baby', 'hot'].includes(phrase))) { phrase += ' ' + words[++i]; }
      const c = colorOf(phrase);
      if (c) { if (!col) col = c; else if (!col2) col2 = c; }
      continue;
    }
    const p = patternOf(w) || patternOf(words[i] + ' ' + (words[i + 1] || ''));
    if (p && p !== 'solid') { pat = p; continue; }
    if (p === 'solid') continue;
    rest.push(w);
  }
  const phrase = rest.join(' ');
  const f = find(phrase);
  if (!f) { if (phrase) missing.push(phrase); return; }
  if (f.kind === 'outfit') { expandOutfit(f.id, items, missing, col); return; }
  addItem(items, { id: f.id, col, col2, pat });
}
function expandOutfit(id, items, missing, col) {
  const o = OUTFITS.get(id);
  if (!o) return;
  let first = true;
  for (const spec of o.items) {
    const before = items.length;
    chunkToItem(spec, items, missing);
    if (first && col) { const g = items.find((x) => x.slot === 'top' || x.slot === 'outer' || x.slot === 'dress'); if (g) g.col = col; }
    first = false;
  }
}

const PLAN_CACHE = new Map();
/**
 * Reads what a person wears. spec: a sentence ('red hoodie, blue jeans, beanie'), a costume name ('doctor'), a list, or an object
 *   { outfit:'chef', top:'red', bottom:{ item:'jeans', color:'navy', pattern:'stripes' }, hat:'cap', glasses:'sunglasses', shoes:'boots', bag:'backpack', extra:[...] }
 */
export function plan(spec) {
  if (spec == null || spec === false || spec === '' || (typeof spec === 'string' && /^(none|nothing|no|default|off)$/i.test(spec.trim()))) return null;
  const ck = typeof spec === 'string' ? spec : JSON.stringify(spec);
  if (PLAN_CACHE.has(ck)) return PLAN_CACHE.get(ck);
  const items = [], missing = [];
  const feed = (v, hint) => {
    if (v == null || v === false) return;
    if (Array.isArray(v)) { for (const x of v) feed(x, hint); return; }
    if (typeof v === 'string') {
      for (const c of v.split(/,|;|\+|\band\b|\bwith\b|\bplus\b|&/i)) chunkToItem(c, items, missing);
      return;
    }
    if (typeof v === 'object') {
      const nm = v.item || v.name || v.id || v.type || v.wear;
      const col = colorOf(v.color || v.colour || v.c || ''), col2 = colorOf(v.color2 || v.colour2 || v.accent || ''), pat = patternOf(v.pattern || v.print || '');
      if (nm) {
        const f = GARMENTS.has(String(nm)) ? { kind: 'item', id: String(nm) } : find(String(nm));
        if (f && f.kind === 'item') addItem(items, { id: f.id, col, col2, pat, num: v.number });
        else if (f && f.kind === 'outfit') expandOutfit(f.id, items, missing, col);
        else missing.push(String(nm));
      }
    }
  };
  if (spec && typeof spec === 'object' && !Array.isArray(spec) && !spec.item && !spec.name && !spec.id) {
    // an object of named slots
    const order = ['outfit', 'costume', 'dress', 'top', 'shirt', 'bottom', 'trousers', 'pants', 'skirt', 'outer', 'jacket', 'coat', 'shoes', 'shoe', 'footwear', 'hat', 'head', 'headwear', 'glasses', 'eyewear', 'face', 'mask', 'neck', 'scarf', 'tie', 'necklace', 'bag', 'back', 'belt', 'waist', 'jewelry', 'jewellery', 'earrings', 'accessories', 'extra', 'items', 'list'];
    for (const k of order) if (spec[k] != null) {
      const v = spec[k];
      if (typeof v === 'string' && ['top', 'shirt', 'bottom', 'trousers', 'pants', 'skirt', 'jacket', 'coat', 'outer', 'dress', 'neck', 'scarf', 'tie'].includes(k) && !find(v) && colorOf(v)) {
        // a bare colour for a slot: 'top:"red"' -> recolour whatever the slot is (a plain top/trousers by default)
        const base = { top: 'tshirt', shirt: 'shirt', bottom: 'jeans', trousers: 'pants', pants: 'pants', skirt: 'skirt', jacket: 'jacket', coat: 'overcoat', outer: 'jacket', dress: 'dress', neck: 'scarf', scarf: 'scarf', tie: 'tie' }[k];
        addItem(items, { id: base, col: colorOf(v) });
      } else feed(v);
    }
  } else feed(spec);
  const p = items.length || missing.length ? { items, missing, key: items.map((i) => `${i.id}|${i.col}|${i.col2}|${i.pat}`).join(';'), text: ck.slice(0, 120) } : null;
  if (PLAN_CACHE.size > 400) PLAN_CACHE.clear();
  PLAN_CACHE.set(ck, p);
  return p;
}

/** Pulls the wardrobe request out of a character's look (look.wear, or the outfit/hat/glasses words the built-in styles do not know). */
export function planOf(look) {
  if (!look || typeof look !== 'object') return null;
  if (look.wear != null) return plan(look.wear);
  if (look.wardrobe != null) return plan(look.wardrobe);
  if (look.costume != null) return plan(look.costume);
  return null;
}

// ---------------------------------------------------------------- the built-in styles
// native(look, plan, style): the look with the style's OWN clothing fields set to match the plan (sleeves, trousers, shoes, colours),
// so arms, legs and feet (which the built-in drawings move) wear the plan's colours. Returns { look, handled:Set(ids drawn natively) }.
const HUMAN_BOTTOM_LONG = (nat) => nat.h;
export function native(look, pl, style) {
  const L = { ...(look || {}) };
  const handled = new Set();
  if (!pl) return { look: L, handled };
  const by = (slot) => pl.items.filter((i) => i.slot === slot);
  const top = by('dress')[0] || by('outer')[0] || by('top')[0];
  const inner = by('top')[0];
  const bottom = by('bottom')[0], feet = by('feet')[0], eyes = by('eyes')[0];
  const g = (it) => it && GARMENTS.get(it.id);
  const armSrc = top || inner;
  const armNat = armSrc ? (g(armSrc).nat || {}) : {};
  const shoeNat = feet ? (g(feet).nat || {}) : {};
  if (style === 'original') {
    L._arm = armNat.arm || (armSrc ? 'cloth' : undefined);
    if (armSrc) { L.outfitc = armSrc.col; L.outfit = 'crew'; }
    if (bottom) L._pants = bottom.col; else if (top && (top.slot === 'dress' || by('dress')[0])) L._pants = '#3a3a3a';
    if (feet) L._shoe = feet.col;
    L._wm = true;
  } else if (style === 'stickman') {
    if (armSrc) { L.topc = armSrc.col; L.top = armNat.s || 'tshirt'; }
    if (bottom) { const n = g(bottom).nat || {}; L.bottomc = bottom.col; L.bottom = n.skirt ? 'skirt' : (n.p || 'jeans'); }
    if (feet) { L.shoec = feet.col; L.shoe = shoeNat.s || 'sneakers'; }
    if (by('head')[0]) L.headwear = 'none';
    if (eyes) L.eyewear = 'none';
    if (by('bag')[0] || by('back')[0]) L.acc = [];
    if (by('neck')[0]) L.acc = [];
  } else if (style === 'human') {
    if (top && armNat.h) {
      L.top = armNat.h; L.topc = top.col; if (top.pat && ['stripes', 'pinstripe', 'plaid', 'gingham', 'dots', 'floral', 'chevron', 'houndstooth', 'sequin'].includes(top.pat)) { L.pattern = top.pat === 'polka' ? 'dots' : top.pat; if (top.col2) L.accentc = top.col2; }
      handled.add(top.id);
      if (top.slot === 'dress') L.top = 'dress';
      if (inner && top !== inner && g(inner).nat && g(inner).nat.h) { L.innerc = inner.col; handled.add(inner.id); }
    }
    if (bottom && !by('dress')[0]) { const n = g(bottom).nat || {}; if (n.h) { L.bottom = n.h; L.bottomc = bottom.col; handled.add(bottom.id); } }
    if (feet) L.shoec = feet.col;
    if (eyes && (g(eyes).nat || {}).h) { L.glasses = g(eyes).nat.h; handled.add(eyes.id); }
    if (by('head')[0]) { L.headpiece = 'none'; }
  } else if (style === 'doodle') {
    if (armSrc) { L.topc = armSrc.col; L.stripes = armSrc.pat === 'stripes'; }
    L.bit = 'none';
  }
  return { look: L, handled };
}

// ---------------------------------------------------------------- the drawings
const LAYER_CACHE = new Map();
/** The clothes as drawings. ctx: { view, gender, build, rig, head, uid, handled (a Set of item ids the style draws itself) } */
export function layers(pl, style, ctx = {}) {
  if (!pl) return null;
  const handled = ctx.handled || new Set();
  const items = pl.items.filter((i) => !handled.has(i.id));
  const key = [pl.key, style, ctx.view, ctx.gender, ctx.build, [...handled].join(','), ctx.rig ? JSON.stringify(ctx.rig) : '', ctx.head ? JSON.stringify(ctx.head) : '', ctx.uid].join('#');
  const hit = LAYER_CACHE.get(key);
  if (hit) return hit;
  const r = renderPlan({ items }, { ...ctx, style }, GARMENTS);
  if (LAYER_CACHE.size > 300) LAYER_CACHE.clear();
  LAYER_CACHE.set(key, r);
  return r;
}

/** Puts the clothes on a finished character picture. Styles with hooks already drew `mid` and `head` inside the picture (hooked = true). */
export function wrap(svg, L, o = {}) {
  if (!L) return svg;
  const defs = L.defs ? `<defs>${L.defs}</defs>` : '';
  const stat = o.hooked ? '' : `${L.mid || ''}${L.head || ''}`;
  return `${defs}${L.back || ''}${svg}${stat}${L.front || ''}`;
}

// ---------------------------------------------------------------- numbers and prompt text
/** How many different pieces the wardrobe can make: every item x every colour (x every fabric pattern for cloth). Costumes are extra. */
export function countVariants() {
  let total = 0;
  const colours = COLOR_LIST.length;
  for (const g of GARMENTS.values()) total += colours * (g.pat ? PATTERNS.length : 1);
  return total;
}
export const VARIANTS = countVariants();
export const COUNTS = Object.freeze({ items: GARMENTS.size, outfits: OUTFITS.size, colours: COLOR_LIST.length, patterns: PATTERNS.length, variants: VARIANTS });

const CAT_LABEL = { top: 'TOPS', outer: 'COATS & JACKETS', dress: 'DRESSES & SUITS', bottom: 'TROUSERS & SKIRTS', head: 'HATS & HEADWEAR', eyes: 'GLASSES', face: 'FACE', neck: 'NECKWEAR', feet: 'SHOES', bag: 'BAGS', back: 'BACK PIECES', waist: 'BELTS', jewel: 'JEWELLERY' };
export function catalogPrompt() {
  const bySlot = {};
  for (const g of GARMENTS.values()) (bySlot[g.slot] = bySlot[g.slot] || []).push(g.id);
  const lines = Object.keys(CAT_LABEL).filter((s) => bySlot[s]).map((s) => `${CAT_LABEL[s]}: ${bySlot[s].join(', ')}`);
  return `WARDROBE (ready clothes, ${GARMENTS.size} pieces x ${COLOR_LIST.length} colours x ${PATTERNS.length} fabric patterns, and ${OUTFITS.size} whole costumes). Write what a person wears as plain words in the look: look:{..., wear:'red striped hoodie, navy jeans, white sneakers, beanie, backpack'}. Any colour word or #hex, any pattern word (${PATTERNS.filter((p) => p !== 'solid').slice(0, 18).join(', ')}...), and any ordinary clothing word works; ready costumes are used by name: wear:'doctor' | 'police' | 'chef' | 'knight' | 'nigerian' | 'bride' ... (${OUTFIT_IDS.join(', ')}). Mix them: wear:'chef, red scarf'. The same words fit every character style (default, stickman, human, doodle) and uploaded characters. Only draw a piece yourself when nothing here is close. PICK UP / PUT DOWN: a prop with hold:'name' plus pick:[t0,t1] (lies at its own x,y, then flies to the hand and is carried) and drop:[t2,t3] (set back down at its own x,y); time the arm reach with the same numbers.
Ids: ${lines.join(' | ')}`;
}
export function catalogShort() {
  return `look.wear:'red hoodie, jeans, beanie' or a costume ('doctor','chef','knight'..) dresses any character; never draw clothes.`;
}
export function api() { return { find, plan, planOf, native, layers, wrap, catalogPrompt, catalogShort, ITEM_IDS, OUTFIT_IDS, COUNTS, VARIANTS }; }
