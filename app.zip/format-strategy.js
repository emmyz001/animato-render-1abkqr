// FORMAT STRATEGY: a 30-second vertical clip and a 12-minute YouTube video are NOT the same product, so they are not paced, built or filmed the same way.
//
// formatOf({seconds, ar}) picks the profile:
//   short  up to 90 s, or a tall (9:16) video up to 3 min     one idea, hook in 1 s, a change every 2-3 s, ends so it loops
//   mid    90 s up to 8 min                                   hook + 3 to 6 beats, a change every 3-5 s, one big reveal
//   long   8 min and more (10 to 30 min)                      hook + promise, chapters, a small change every 5-8 s and a big one every 30-40 s,
//                                                             an energy curve with breathers, open loops, re-hooks, a payoff, a quiet strong ending
// The profile does three things: it adds a block to the AI prompt (formatBlock), tells each chapter its role (chapterRole), and sets how
// often and how hard the engagement pass adds camera punch-ins and key words (profile.engage), so a long film is steady instead of twitchy.
// No look-behind regex (older iPhones).

const num = (v, d = 0) => (Number.isFinite(+v) ? +v : d);

export const PROFILES = {
  short: {
    id: 'short', name: 'Short-form', hold: 4,
    engage: { gap: 3.2, popGap: 4.6, cadence: 2.6, amt: 0.075, rehooks: [15, 30, 60], every: 60 },
  },
  mid: {
    id: 'mid', name: 'Mid-length', hold: 5,
    engage: { gap: 4.4, popGap: 6.4, cadence: 3.6, amt: 0.065, rehooks: [20, 45, 90], every: 75 },
  },
  long: {
    id: 'long', name: 'Long-form', hold: 8,
    engage: { gap: 6.5, popGap: 9, cadence: 5.5, amt: 0.05, rehooks: [30, 75, 150], every: 120 },
  },
};

export function formatOf({ seconds, ar } = {}) {
  const s = num(seconds, 60), tall = ar === '9:16';
  if (s <= 90 || (tall && s <= 180)) return PROFILES.short;
  if (s < 480) return PROFILES.mid;
  return PROFILES.long;
}

/** how many chapters a long film has: about one every 90 to 150 seconds */
export function chapterCount(seconds) {
  return Math.max(1, Math.round(num(seconds, 60) / 120));
}

export const FORMAT_MARKER = 'FORMAT STRATEGY';

const SHORT = `${FORMAT_MARKER} (SHORT-FORM, built to be watched to the end AND watched again; this decides the pace and replaces any slower pace rule above):
- ONE idea, ONE payoff. No intro, no title card, no "hello", no chapters.
- Second 0 to 1: the most striking picture and a hook line that makes people ask "wait, what?" (a shock, a bold claim, a question that needs the answer).
- Change something every 2 to 3 seconds (shot, prop, face, on-screen word). Never the same framing for more than 4 seconds.
- Frame for a phone: faces big, one subject at a time, big captions, the key word of each sentence on screen.
- Say the surprising part at about two thirds, then land it fast.
- The last line ends so that the first line makes sense again (a loop), or on a question that makes people comment. No outro, no "thanks for watching".`;

const MID = `${FORMAT_MARKER} (MID-LENGTH, a few minutes, built so people stay and the second half is better than the first; this replaces any faster pace rule above):
- Hook in the first 3 seconds, then a one-sentence promise of what the viewer will get ("by the end you will know why...").
- 3 to 6 beats. Each beat = a question, the build, a small payoff, and a line that pulls into the next beat. The biggest reveal sits at about 70 percent.
- Something new on screen every 3 to 5 seconds; a new place or situation every 25 to 40 seconds. Never more than 2 shots of the same kind in a row.
- One breather beat (quieter, slower, fewer things moving) before the biggest reveal, so it hits harder.
- A short recap line before the end, then the payoff, then one closing line. No long goodbye.`;

const LONG = `${FORMAT_MARKER} (LONG-FORM, 10 minutes and more: this is built to hold people for the WHOLE video, so it is planned in chapters, and this section REPLACES the "something new every 2 to 3 seconds" pace rule above, which would exhaust viewers over 10 minutes):
STRUCTURE
- COLD OPEN (first 15 to 25 seconds): show the most gripping moment of the whole story first, then the PROMISE in one sentence ("by the end you will know X"), then a reason to stay. No logo, no long introduction.
- CHAPTERS of about 90 to 150 seconds. Every chapter has: a clear question or problem, a build, a small payoff, and an OPEN LOOP at its end (a question or a hint that only the next chapter answers). Open each chapter with a short title card (scene with chapter:true, plain dark background, big title) or a clear change of place.
- ENERGY CURVE: do not run at full volume for ten minutes. Alternate high chapters (fast, loud, reveals) with breathers (calmer, slower, fewer moving things). The biggest reveal sits at about 70 to 80 percent. Put a re-hook ("but that was not the real problem") at about 30 to 40 percent and again at about 60 percent.
- RAISE THE STAKES every chapter: each one must be bigger, stranger or more personal than the one before.
- CALLBACKS: bring back a person, object or line from an earlier chapter at least three times (a running motif). It rewards viewers who stayed.
- ENDING: a short recap line, the payoff that answers the promise, one closing line. No fake endings, no long goodbye, no "like and subscribe" speech.
RHYTHM
- A small change every 5 to 8 seconds (a new shot, prop, face or on-screen word). A BIG change every 30 to 40 seconds (a new place, a new situation, a new character). Do not stay in the same place for more than about 75 seconds.
- Never use the same shot type more than twice in a row. Vary wide, medium, close, over-the-shoulder, point-of-view.
- Hold a shot 4 to 7 seconds when something is being explained, and cut faster only when the action does.
- A viewer should be able to look away for a moment and still follow: the key idea of every minute is also on screen as a word, a number or a drawing.
- Ask the viewer a question about every 45 seconds and answer it a little later.
CAMERA (steady, not jumpy)
- Slow, smooth pushes and pans that have a reason: push in on a feeling, pull back to reveal, follow a character who walks. At most one big move per scene. No constant shaking; shake only for an impact.`;

export function formatBlock(fmt) {
  const f = fmt && fmt.id ? fmt : PROFILES.mid;
  return f.id === 'short' ? SHORT : f.id === 'long' ? LONG : MID;
}

/** appends the block once; a prompt that already has it is returned unchanged */
export function withFormat(prompt, { seconds, ar } = {}) {
  const text = String(prompt == null ? '' : prompt);
  if (!text || text.indexOf(FORMAT_MARKER) >= 0) return text;
  return text + '\n\n' + formatBlock(formatOf({ seconds, ar }));
}

/** what chapter k of n has to do (k counts from 1), for the prompts that write one chapter at a time */
export function chapterRole(k, n, fmt) {
  if (!fmt || fmt.id === 'short' || n < 2) return '';
  const p = k / n;
  let role;
  if (k === 1) role = 'COLD OPEN AND SETUP: open on the most gripping moment, state the promise in one sentence, then start answering. End on an open loop.';
  else if (k === n) role = 'FINALE: a short recap line, then the payoff that answers the promise, then one closing line. Calm, strong, no long goodbye.';
  else if (p >= 0.65 && p < 0.9) role = 'BIGGEST REVEAL: the most surprising turn of the whole film lands here. Put a breather just before it so it hits harder. Bring back an earlier motif.';
  else if (p >= 0.3 && p < 0.45) role = 'RE-HOOK: a turn that changes what the viewer thought ("but that was not the real problem"). Raise the stakes. End on an open loop.';
  else role = 'BUILD: answer the last open loop, raise the stakes, introduce something new, and end on a new open loop. A breather is allowed in the first half of this chapter.';
  return `${FORMAT_MARKER} FOR THIS CHAPTER (chapter ${k} of ${n}): ${role} Open with a short title card or a clear change of place. Change something small every 5 to 8 seconds and something big every 30 to 40 seconds.`;
}
