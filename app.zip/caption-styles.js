// CAPTION STYLES: the person chooses how the words look. Every style draws the same lines of words (the word being spoken is `act`)
// into the same place, so the picture, the preview and the exported video all agree.
//   bold      the app's own punchy look (Impact, yellow word being said; tall videos show 1 to 3 big words at a time)   [default]
//   classic   film subtitles: white serif, soft shadow, nothing else
//   cinema    streaming-service subtitles: clean semi-bold sans, thin black outline
//   karaoke   the whole line stays; the word being said sits in a yellow bar
//   pill      a rounded dark box behind each line, the spoken word in aqua
//   neon      glowing cyan letters, the spoken word in pink
//   outline   white letters, heavy black outline, words not yet said are dimmed
//   pop       words appear one by one and pop, in capitals (the short-video look)
//   minimal   small, light, spaced letters for documentaries
// render(style, ctx) returns an SVG string (or null for "bold", which the player draws itself).
// ctx = {ls: lines of words, act: index of the word being said (counting across lines), sz, lh, y0, ka (0..1 fade in), esc, P9}

export const STYLES = [
  { id: 'bold', name: 'Bold', hint: 'Big, punchy, yellow word' },
  { id: 'classic', name: 'Classic', hint: 'Film subtitles, white serif' },
  { id: 'cinema', name: 'Cinema', hint: 'Clean streaming look' },
  { id: 'karaoke', name: 'Karaoke', hint: 'Yellow bar on the spoken word' },
  { id: 'pill', name: 'Pill', hint: 'Rounded dark box' },
  { id: 'neon', name: 'Neon', hint: 'Glowing letters' },
  { id: 'outline', name: 'Outline', hint: 'Heavy outline, dimmed next words' },
  { id: 'pop', name: 'Pop', hint: 'Words pop in one by one' },
  { id: 'minimal', name: 'Minimal', hint: 'Small, light, spaced' },
];
export const DEFAULT_STYLE = 'bold';
export const isStyle = (id) => STYLES.some((s) => s.id === id);

const SANS = "'Helvetica Neue',Helvetica,Arial,sans-serif", BLACK = "Impact,'Arial Black',Arial,sans-serif", SERIF = "Georgia,'Times New Roman',serif";
const num = (v, d = 0) => (Number.isFinite(+v) ? +v : d);

function lineX(words, cw, gap) { const w = words.join(' ').length * cw + gap; return { w, x0: 800 - w / 2 }; }

export function render(style, c) {
  if (!isStyle(style) || style === 'bold') return null;
  const { ls, act, esc } = c, ka = num(c.ka, 1), P9 = !!c.P9;
  const sz0 = num(c.sz, 50), lh0 = num(c.lh, sz0 * 1.2);
  let out = '', wi = 0;
  const f = { classic: .86, cinema: .82, karaoke: .9, pill: .82, neon: .9, outline: .96, pop: 1, minimal: .72 }[style] || 1;
  const sz = Math.round(sz0 * f), lh = Math.max(lh0 * f, sz * 1.18), nl = ls.length;
  // the block sits where the app's own captions sit (bottom third); smaller styles sit a little lower
  const yb = num(c.y0, 800) + (nl - 1) * lh0 + (style === 'minimal' ? 18 : style === 'classic' || style === 'cinema' ? 10 : 0);
  const y0 = yb - (nl - 1) * lh;
  const cwOf = { classic: .47, cinema: .53, karaoke: .6, pill: .55, neon: .62, outline: .6, pop: .62, minimal: .5 }[style] * sz;

  if (style === 'pop') {
    // only the words said so far, in capitals; the newest one pops
    const upto = Math.max(0, act);
    ls.forEach((ln, li) => {
      const shown = ln.map((w) => ({ w, k: wi++ })).filter((x) => x.k <= upto);
      if (!shown.length) return;
      const txt = shown.map((x) => `<tspan fill="${x.k === upto ? '#ffd54a' : '#ffffff'}" ${x.k === upto ? 'font-size="' + Math.round(sz * 1.14) + '"' : ''}>${esc(x.w.toUpperCase())}</tspan>`).join('<tspan> </tspan>');
      out += `<text x="800" y="${(y0 + li * lh).toFixed(0)}" text-anchor="middle" font-size="${sz}" font-weight="900" font-family="${BLACK}" letter-spacing="1" fill="#fff" stroke="#000" stroke-width="${(sz * .2).toFixed(1)}" stroke-linejoin="round" paint-order="stroke">${txt}</text>`;
    });
    return `<g opacity="${ka}">${out}</g>`;
  }

  ls.forEach((ln, li) => {
    const y = (y0 + li * lh).toFixed(0), words = ln.map((w) => ({ w, k: wi++ })), plain = ln.join(' ');
    const tsp = (fn) => words.map((x) => `<tspan fill="${fn(x.k)}">${esc(x.w)}</tspan>`).join('<tspan> </tspan>');
    if (style === 'classic') {
      out += `<text x="802" y="${+y + 2}" text-anchor="middle" font-size="${sz}" font-weight="600" font-family="${SERIF}" fill="#000" opacity=".55">${esc(plain)}</text><text x="800" y="${y}" text-anchor="middle" font-size="${sz}" font-weight="600" font-family="${SERIF}" fill="#fff">${esc(plain)}</text>`;
    } else if (style === 'cinema') {
      out += `<text x="800" y="${y}" text-anchor="middle" font-size="${sz}" font-weight="600" font-family="${SANS}" fill="#fff" stroke="#000" stroke-width="${(sz * .13).toFixed(1)}" stroke-linejoin="round" paint-order="stroke">${esc(plain)}</text>`;
    } else if (style === 'minimal') {
      out += `<text x="800" y="${+y + 1.5}" text-anchor="middle" font-size="${sz}" font-weight="300" font-family="${SANS}" letter-spacing="${(sz * .08).toFixed(1)}" fill="#000" opacity=".5">${esc(plain.toLowerCase())}</text><text x="800" y="${y}" text-anchor="middle" font-size="${sz}" font-weight="300" font-family="${SANS}" letter-spacing="${(sz * .08).toFixed(1)}" fill="#fff">${esc(plain.toLowerCase())}</text>`;
    } else if (style === 'outline') {
      // words not said yet are dimmed (fill and outline both)
      const t = words.map((x) => { const o = x.k <= act ? 1 : .5; return `<tspan fill="#fff" fill-opacity="${o}" stroke-opacity="${o}">${esc(x.w)}</tspan>`; }).join('<tspan> </tspan>');
      out += `<text x="800" y="${y}" text-anchor="middle" font-size="${sz}" font-weight="900" font-family="${BLACK}" letter-spacing="1" stroke="#000" stroke-width="${(sz * .24).toFixed(1)}" stroke-linejoin="round" paint-order="stroke">${t}</text>`;
    } else if (style === 'neon') {
      const base = `x="800" y="${y}" text-anchor="middle" font-size="${sz}" font-weight="900" font-family="${BLACK}" letter-spacing="1"`;
      out += `<text ${base} fill="none" stroke="#19e6ff" stroke-width="${(sz * .3).toFixed(1)}" stroke-linejoin="round" opacity=".18">${esc(plain)}</text><text ${base} fill="none" stroke="#19e6ff" stroke-width="${(sz * .16).toFixed(1)}" stroke-linejoin="round" opacity=".4">${esc(plain)}</text><text ${base} stroke="#0aa7c2" stroke-width="2" stroke-linejoin="round">${tsp((k) => (k === act ? '#ff7be9' : '#ffffff'))}</text>`;
    } else if (style === 'pill') {
      const { w, x0 } = lineX(ln, cwOf, sz * .9), h = sz * 1.3;
      out += `<rect x="${x0.toFixed(0)}" y="${(y - sz * .98).toFixed(0)}" width="${w.toFixed(0)}" height="${h.toFixed(0)}" rx="${(h / 2).toFixed(0)}" fill="#000" opacity=".62"/><text x="800" y="${y}" text-anchor="middle" font-size="${sz}" font-weight="700" font-family="${SANS}">${tsp((k) => (k === act ? '#5ee7ff' : '#ffffff'))}</text>`;
    } else if (style === 'karaoke') {
      const total = plain.length * cwOf, x0 = 800 - total / 2;
      let xx = x0, bars = '', txt = '';
      for (const x of words) {
        const ww = x.w.length * cwOf, on = x.k === act;
        if (on) bars += `<rect x="${(xx - sz * .12).toFixed(0)}" y="${(y - sz * .9).toFixed(0)}" width="${(ww + sz * .24).toFixed(0)}" height="${(sz * 1.15).toFixed(0)}" rx="${(sz * .2).toFixed(0)}" fill="#ffd54a"/>`;
        txt += `<text x="${(xx + ww / 2).toFixed(0)}" y="${y}" text-anchor="middle" font-size="${sz}" font-weight="900" font-family="${BLACK}" letter-spacing="1" fill="${on ? '#111' : '#fff'}" ${on ? '' : `stroke="#000" stroke-width="${(sz * .18).toFixed(1)}" stroke-linejoin="round" paint-order="stroke"`}>${esc(x.w)}</text>`;
        xx += ww + cwOf;
      }
      out += bars + txt;
    }
  });
  return `<g opacity="${ka}">${out}</g>`;
}

/** a small picture of a style, for the picker */
export function sampleSvg(style) {
  const esc = (s) => String(s).replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));
  const ls = [['She', 'opened', 'the', 'door']];
  let inner = render(style, { ls, act: 1, sz: 66, lh: 80, y0: 560, ka: 1, esc, P9: false });
  if (inner == null) inner = `<text x="800" y="560" text-anchor="middle" font-size="66" font-weight="900" font-family="${BLACK}" letter-spacing="1" stroke="#000" stroke-width="14" stroke-linejoin="round" paint-order="stroke"><tspan fill="#fff">She </tspan><tspan fill="#ffd54a">opened </tspan><tspan fill="#fff">the door</tspan></text>`;
  return `<svg viewBox="400 470 800 140" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet"><rect x="400" y="470" width="800" height="140" fill="#2b3446"/>${inner}</svg>`;
}
