// Scene catalog: the list of ready places, how to ask for one, and the short text that tells the AI about them.
//
//   build('subway', {time:'night', weather:'rain', seed:3})  -> { svg, layers, meta }
//   find('a rainy subway platform at night')                  -> { id:'subway', time:'night', weather:'rain', seed:0 } | null
//   locFn('subway')                                           -> (opts) => svg   (what LOC.subway(...) calls)
//   catalogPrompt()                                           -> the compact list for the AI prompt (about 700 tokens for ~190 places)
//
// Pure functions, no DOM. index.html merges locFn into LOC; generation.js resolves  s:'subway night rain'  through find().

import { makeKit, composeSvg, TIMES, WEATHERS, SEEDS, W, H } from './scene-library.js';
import { INDOOR } from './scene-places-in.js';
import { OUTDOOR } from './scene-places-out.js';

const REG = new Map();
for (const p of [...INDOOR, ...OUTDOOR]) REG.set(p.id, p); // later entries win (the outdoor file holds the classic names)

export const PLACES = Object.freeze([...REG.values()]);
export const PLACE_IDS = Object.freeze(PLACES.map((p) => p.id));
export const CATEGORIES = Object.freeze(['home', 'shop', 'work', 'studio', 'transit', 'city', 'nature', 'fantasy', 'scifi', 'sport']);
const CAT_LABEL = { home: 'HOME', shop: 'SHOPS & FOOD', work: 'WORK & PUBLIC', studio: 'STUDIO & ABSTRACT', transit: 'TRAVEL', city: 'CITY', nature: 'NATURE', fantasy: 'HISTORY & FANTASY', scifi: 'SCI-FI', sport: 'SPORT' };

/** How many distinct pictures the library can make: places x times x weathers x seeds. */
export const VARIANTS = PLACES.length * TIMES.length * WEATHERS.length * SEEDS;

const norm = (s) => String(s == null ? '' : s).replace(/([a-z])([A-Z])/g, '$1 $2').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
const RESERVED = new Set(['room', 'night', 'outdoor', 'black', 'then', 'tojson', 'constructor', 'prototype', 'stage', 'valueof', 'tostring']);

// ---- word index for fuzzy matching ---------------------------------------------------------------
const IDX = []; // { phrase, id, w }
for (const p of PLACES) {
  const add = (ph, w) => { const n = norm(ph); if (n && !RESERVED.has(n)) IDX.push({ phrase: n, id: p.id, w }); };
  add(p.id, 12);
  for (const a of p.aka || []) add(a, 10);
}
const STOP = new Set(['a', 'an', 'the', 'of', 'in', 'at', 'on', 'with', 'and', 'to', 'for', 'near', 'inside', 'outside', 'scene', 'place', 'background', 'view', 'room', 'area']);
const TIME_WORDS = { day: 'day', daytime: 'day', noon: 'day', afternoon: 'day', sunny: 'day', morning: 'morning', dawn: 'morning', sunrise: 'morning', daybreak: 'morning', dusk: 'dusk', evening: 'dusk', sunset: 'dusk', twilight: 'dusk', golden: 'dusk', night: 'night', midnight: 'night', nighttime: 'night', dark: 'night', moonlit: 'night', overcast: 'overcast', cloudy: 'overcast', gloomy: 'overcast', grey: 'overcast', gray: 'overcast' };
const WEATHER_WORDS = { clear: 'clear', rain: 'rain', rainy: 'rain', raining: 'rain', wet: 'rain', drizzle: 'rain', snow: 'snow', snowy: 'snow', snowing: 'snow', winter: 'snow', fog: 'fog', foggy: 'fog', mist: 'fog', misty: 'fog', storm: 'storm', stormy: 'storm', thunder: 'storm', thunderstorm: 'storm', lightning: 'storm' };

/** Splits "a rainy subway platform at night #3" into the place words, the time, the weather and the seed. */
export function parseRequest(text) {
  let t = norm(text), seed, time, weather;
  t = t.replace(/\b(?:seed|variant|v|style)\s*(\d{1,3})\b/g, (_, n) => { seed = +n; return ' '; }).replace(/\s#\s*(\d{1,3})\b/g, (_, n) => { seed = +n; return ' '; });
  const words = [];
  for (const w of t.split(' ')) {
    if (!w) continue;
    if (/^\d+$/.test(w) && seed == null && words.length) { seed = +w; continue; }
    if (TIME_WORDS[w] && !time) time = TIME_WORDS[w]; else if (WEATHER_WORDS[w] && !weather) weather = WEATHER_WORDS[w]; else words.push(w);
  }
  return { words, time, weather, seed };
}

/** The place a phrase means (exact id or alias first, then the best word overlap), with its time, weather and seed. Null when nothing fits. */
export function find(text) {
  const req = parseRequest(text);
  const phrase = req.words.join(' ');
  if (!phrase || RESERVED.has(phrase)) return null;
  const pad = ' ' + phrase + ' ';
  let best = null, bs = 0;
  for (const e of IDX) {
    let s = 0;
    if (phrase === e.phrase) s = 100 + e.w;
    else if (pad.includes(' ' + e.phrase + ' ')) s = 40 + e.phrase.length + e.w;
    else {
      const ew = e.phrase.split(' ').filter((x) => !STOP.has(x)), pw = req.words.filter((x) => !STOP.has(x));
      if (!ew.length || !pw.length) continue;
      const hit = ew.filter((x) => pw.some((y) => y === x || (y.length > 4 && x.length > 4 && (y.startsWith(x) || x.startsWith(y)) && Math.min(x.length, y.length) / Math.max(x.length, y.length) >= .7))).length;
      if (hit === ew.length && hit >= 1 && (ew.length > 1 || ew[0].length > 3)) s = 14 + hit * 4 + e.w * .1;
      else if (hit && ew.length > 1) s = hit * 3;
    }
    if (s > bs) { bs = s; best = e; }
  }
  if (!best || bs < 14) return null;
  return { id: best.id, time: req.time, weather: req.weather, seed: req.seed, score: bs };
}

const cleanOpts = (o) => {
  if (typeof o === 'string') { const r = parseRequest(o); o = { time: r.time, weather: r.weather, seed: r.seed }; }
  o = o && typeof o === 'object' ? o : {};
  const time = TIMES.includes(String(o.time || o.mood)) ? String(o.time || o.mood) : (TIME_WORDS[String(o.time || o.mood || '').toLowerCase()] || 'day');
  const weather = WEATHERS.includes(String(o.weather)) ? String(o.weather) : (WEATHER_WORDS[String(o.weather || '').toLowerCase()] || 'clear');
  const seed = Number.isFinite(+o.seed) ? Math.abs(Math.floor(+o.seed)) % 1000 : 0;
  return { time, weather, seed };
};

const CACHE = new Map();
const CACHE_MAX = 16;

/** Builds one place. Returns { svg, layers:[{name,svg}], meta:{id,time,weather,seed,floor,cat,out} }. Unknown ids fall back to the closest place, then to a city. */
export function build(id, opts) {
  let p = REG.get(id);
  let o = cleanOpts(opts);
  if (!p) {
    const f = find(id);
    p = f && REG.get(f.id);
    if (f) o = { time: f.time || o.time, weather: f.weather || o.weather, seed: f.seed ?? o.seed };
    if (!p) p = REG.get('cityDay');
  }
  const key = p.id + '|' + o.time + '|' + o.weather + '|' + o.seed;
  const hit = CACHE.get(key);
  if (hit) return hit;
  const k = makeKit(p.id, o);
  p.make(k);
  const out = { svg: composeSvg(k), layers: k.layers.map((l) => ({ name: l.name, svg: l.s })), meta: { id: p.id, time: k.time, weather: k.weather, seed: k.seed, floor: p.floor, cat: p.cat, out: !!p.out } };
  CACHE.set(key, out);
  if (CACHE.size > CACHE_MAX) CACHE.delete(CACHE.keys().next().value);
  return out;
}

/** What LOC.<name>(opts) calls. Returns null when the name is not a place (so the caller can keep its own handling). */
export function locFn(name) {
  if (typeof name !== 'string' || RESERVED.has(name.toLowerCase())) return null;
  let id = REG.has(name) ? name : null;
  let pre = null;
  if (!id) { const f = find(name); if (f) { id = f.id; pre = f; } }
  if (!id) return null;
  return (opts) => {
    const base = cleanOpts(opts);
    const o = pre ? { time: (opts && opts.time) || pre.time || base.time, weather: (opts && opts.weather) || pre.weather || base.weather, seed: opts && opts.seed != null ? base.seed : (pre.seed ?? base.seed) } : base;
    return build(id, o).svg;
  };
}
export const has = (name) => !!locFn(name);
export const info = (id) => { const p = REG.get(id); return p ? { id: p.id, cat: p.cat, aka: p.aka || [], floor: p.floor, out: !!p.out } : null; };
export const list = (cat) => PLACES.filter((p) => !cat || p.cat === cat).map((p) => p.id);

/** The functions to merge into LOC: one per place, plus get/find/list/layers. (The old LOC.stage stays as it is.) */
export function locApi() {
  const api = {};
  for (const id of PLACE_IDS) api[id] = (opts) => build(id, opts).svg;
  api.get = (text, opts) => { const f = find(text); return build(f ? f.id : text, f ? { time: f.time, weather: f.weather, seed: f.seed, ...(typeof opts === 'object' ? opts : {}) } : opts).svg; };
  api.find = find;
  api.list = list;
  api.layers = (id, opts) => build(id, opts).layers;
  api.info = info;
  return api;
}

/** The short block for the AI prompt. Names only: the AI calls them, it does not draw them. */
export function catalogPrompt() {
  const by = {};
  for (const p of PLACES) (by[p.cat] ||= []).push(p.id);
  const lines = CATEGORIES.filter((c) => by[c]).map((c) => `${CAT_LABEL[c]}: ${by[c].join(', ')}`);
  return `SCENE LIBRARY (${PLACES.length} ready, layered, textured places; thousands of looks). USE THESE FIRST: LOC.<id>({time, weather, seed}) as the scene background, or  s:'<id> <time> <weather>'  in a beat. Draw your own set (SETS.*) ONLY when no id fits the story. This saves most of your tokens.
time: ${TIMES.join(' | ')}. weather: ${WEATHERS.join(' | ')} (outdoors, and through windows). seed 0-${SEEDS - 1}: another colour scheme and different random details (buildings, trees, crowd) of the same place, so use a different seed when a place comes back. Example: LOC.subway({time:'night', weather:'rain', seed:3}).
${lines.join('\n')}
Add story details on top as props (item, titleCard, crowd, rain, ...). Characters stand on the floor line shown in the CHARACTER SIZE GUIDE (about y 740 to 790 here).`;
}

/** A very short form for small prompts. Free words work too: the app finds the closest ready place. */
export function catalogShort() {
  const eg = ['subway', 'hospitalRoom', 'classroom', 'courtroom', 'pineForest', 'beach', 'castle', 'cyberpunk', 'diner'].filter((x) => REG.has(x)).join(', ');
  return `SCENE LIBRARY (${PLACES.length} ready layered places, use first): LOC.<place>({time, weather, seed}) or s:'subway night rain'; plain words work (s:'old hospital corridor'). time ${TIMES.join('|')}; weather ${WEATHERS.join('|')}; seed 0-${SEEDS - 1}. e.g. ${eg}. Own SETS only if none fits.`;
}

export { TIMES, WEATHERS, SEEDS, W, H };
